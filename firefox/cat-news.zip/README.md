# detoxify-news
Remove titles and images from news website to avoid anxiety (when working on a news website…)
